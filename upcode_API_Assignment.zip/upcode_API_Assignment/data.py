products = [
    {"id": 1, "name": "Product A", "price": 10.99, "category": "Electronics", "brand_id": 1},
    {"id": 2, "name": "Product B", "price": 24.99, "category": "Clothing", "brand_id": 2},
    {"id": 3, "name": "Product C", "price": 5.99, "category": "Books", "brand_id": 3},
    {"id": 4, "name": "Product D", "price": 15.99, "category": "Electronics", "brand_id": 1},
    {"id": 5, "name": "Product E", "price": 8.99, "category": "Books", "brand_id": 3},
    {"id": 6, "name": "Product F", "price": 19.99, "category": "Clothing", "brand_id": 2}
]


categories = [
    "Electronics",
    "Clothing",
    "Books",
    "Home & Kitchen",
    "Beauty & Personal Care"
]
