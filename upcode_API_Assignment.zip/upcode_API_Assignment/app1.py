from flask import Flask, jsonify, request
import data

app = Flask(__name__)

def get_products():
    return data.products

def get_categories():
    return data.categories

@app.route('/products', methods=['GET'])
def products_route():
    products = get_products()
    return jsonify(products)

@app.route('/categories', methods=['GET'])
def categories_route():
    categories = get_categories()
    return jsonify(categories)

@app.route('/categories', methods=['POST'])
def add_category():
    data_received = request.get_json()
    if data_received and 'category' in data_received:
        new_category = {"category": data_received['category']}
        data.categories.append(data_received['category'])
        return jsonify({"message": "Category added successfully", "category": new_category}), 201
    else:
        return jsonify({"error": "Invalid data, please provide 'category'"}), 400

if __name__ == '__main__':
    app.run(debug=True)
